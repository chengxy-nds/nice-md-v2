# Changelog

## v2.0.8 (2026-03-17)

- 🆕 新增抖音图文
- 🆕 统一同步对话框和悬浮按钮
- 🆕 设置页增加 CLI 桥接服务器地址配置
- 🔧 修复 CLI 同步格式异常
- 🔧 改善 CLI/MCP 桥接重连稳定性
- 🔧 优化 UI 交互体验
- 🔧 修复多个用户反馈

---

## v2.0.7 (2026-03-10)

- 🆕 新增什么值得买、网易号平台
- 🆕 简书支持 Markdown 格式发布
- 🆕 支持飞书文档提取（仅兼容部分格式）
- 🔧 重新适配简书、一点号、搜狐号平台
- 🔧 修复头条、大鱼号等平台同步兼容性问题
- 🔧 优化UI交互体验

---

## v2.0.6 (2026-02-25)

- 🆕 新增东方财富 (由@mayaohua贡献)
- 🆕 新增悬浮同步按钮（设置中开启，默认关闭）
- 🔧 修复 WordPress / Typecho 部分图片因扩展名错误导致上传失败

---

## v2.0.3

### 🌐 新增平台

**小红书 (Xiaohongshu)**
- 支持长文笔记草稿同步
- ProseMirror JSON 格式输出（专为小红书编辑器优化）
- 图片自动上传并获取签名 URL（`x-ros-preview-url`）
- 图片尺寸自动获取（`createImageBitmap`）+ 显示优化（宽度 410px，按比例缩放）
- 同步完成后 Toast 提示（引导用户去草稿箱 → 长文笔记查看）
- 字数限制 10000 字

**X (Twitter)**
- 基础适配器

### 🔧 稳定性增强

**超时保护机制**
| 操作 | 超时时间 |
|-----|---------|
| `checkAuth` 认证检查 | 10 秒 |
| `publish` 发布操作 | 10 分钟 |
| `runtime.fetch` HTTP 请求 | 30 秒 |
| `tabs.waitForLoad` 页面加载 | 30 秒 |

- 防止 API 卡死导致 UI 无响应
- 超时后返回友好错误提示

### 🆕 内容转换系统

**新增 `packages/core/src/content/` 模块**
- 基于 unified/rehype/remark 生态
- 支持 ProseMirror JSON 输出（小红书专用）
- 平台能力配置化（`capabilities.ts`）
- 可扩展的转换管道

### 🔧 核心修复

**同步 API 恢复**
- 新增 `inject-api.js` + `content/api.ts` - 网页端 `$syncer` API 兼容层
- 支持官网/第三方网站调用扩展功能

**代码块提取**
- 修复 `textContent` → `innerText`

**平台适配器修复**
- 开源中国 - 登录状态检测
- 人人都是产品经理 - 图片上传
- Typecho

### 📝 文档
- ROADMAP 添加用户需求平台排名（基于 527 条反馈）

---

## v2.0.2

### 🌐 平台
- 新增 51CTO、慕课网、SegmentFault、开源中国 适配器

### 🔧 修复
- 新增 `Readability.js` + `reader.js` 文章提取库

---

## v2.0.1

### 🌐 平台
- 新增大鱼号适配器
- 搜狐号重新适配

### 🔧 稳定性
- 代码块格式保留（多行、语言标识）
- LaTeX 公式支持（`<script type="math/tex">` → Markdown）
- 表格格式优化（对齐标记、无表头 fallback、管道符转义）
- 错误提示优化

### 🐛 Bug 修复
- CSDN 图片上传
- CSDN 富文本编辑器冲突

---

## v2.0.0

### ✨ 全新架构
- Manifest V3 升级
- 全新 React UI
- 3 并发同步（速度 ~3x）
- 取消同步功能

### 🌐 平台支持
- 13 个平台适配：知乎、掘金、CSDN、今日头条、百家号、B站、微博、搜狐、语雀、雪球、人人PM、豆瓣、微信公众号

### 🔧 CMS 支持
- WordPress
- Typecho
- MetaWeblog 协议

### 📦 其他
- 兔小巢反馈入口
- v1.x 数据迁移
